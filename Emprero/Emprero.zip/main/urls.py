from django.urls import path
from django.views.decorators.cache import cache_page
from .views import *

urlpatterns = [
    path('', index, name = "index"),
    path('home/',cache_page(60)(Home.as_view()), name = "home"),
    path('description/<slug:card_slug>/',cache_page(60)(Description.as_view()), name = "description"),
    path('us/',cache_page(60)(Us.as_view()), name="us"),
    path('contacts/',cache_page(60)(Contacts.as_view()), name='contacts'),
    path('cart/',cache_page(60)(Cart.as_view()), name='cart'),
    path('login/',cache_page(60)(Login.as_view()), name='login'),
    path('register/',cache_page(60)(Register.as_view()), name='register'),
    path('profile/',cache_page(60)(Profile.as_view()), name='profile'),
]